﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PropertiesAPI.Models
{
    public class RestfulResponse<T> where T : class
    {
    }
}