﻿using PdfSharp;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace FM.Core
{
    public class FileConvertor
    {
        public static byte[] Tiff2Pdf(byte[] bytes)
        {
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            Image image = Image.FromStream(new MemoryStream(bytes));

            PdfDocument doc = new PdfDocument();

            for (int PageIndex = 0; PageIndex < image.GetFrameCount(FrameDimension.Page); PageIndex++)
            {
                image.SelectActiveFrame(FrameDimension.Page, PageIndex);

                XImage img = XImage.FromGdiPlusImage(image);

                var page = new PdfPage();
                //page.Width = img.Width;
                page.Height = img.Height - 50;
                if (img.PixelWidth > img.PixelHeight)
                {
                    page.Orientation = PageOrientation.Landscape;
                }
                else
                {
                    page.Orientation = PageOrientation.Portrait;
                }
                doc.Pages.Add(page);

                XGraphics xgr = XGraphics.FromPdfPage(doc.Pages[PageIndex]);

                xgr.DrawImage(img, 0, 0);
            }

            using (MemoryStream stream = new MemoryStream())
            {
                doc.Save(stream, true);

                doc.Close();
                image.Dispose();

                return stream.ToArray();
            }
        }
    }
}
