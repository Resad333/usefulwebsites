﻿using System.Collections.Generic;

namespace FM.Core
{
    public interface IFileMerger
    {
        byte[] Merge(List<byte[]> list);
    }
}
