﻿using iText.Kernel.Pdf;
using iText.Kernel.Utils;
using System.Collections.Generic;
using System.IO;

namespace FM.Core
{
    public class PdfFileMerger : IFileMerger
    {
        public byte[] Merge(List<byte[]> list)
        {
            using (MemoryStream oMemoryStream = new MemoryStream())
            {
                using (PdfWriter oWriter = new PdfWriter(oMemoryStream))
                {
                    oWriter.SetSmartMode(true);

                    using (PdfDocument oMergedPdf = new PdfDocument(oWriter))
                    {
                        PdfMerger oMerger = new PdfMerger(oMergedPdf, false, false);

                        for (int i = 0; i < list.Count; i++)
                        {
                            PdfDocument oPdfAux = new PdfDocument(new PdfReader(new MemoryStream(list[i])));
                            oMerger.SetCloseSourceDocuments(true).Merge(oPdfAux, 1, oPdfAux.GetNumberOfPages());
                        }
                    }
                }
                return oMemoryStream.ToArray();
            }
        }
    }
}
