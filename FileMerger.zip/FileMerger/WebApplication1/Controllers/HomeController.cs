﻿using FM.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            FileContentResult getPdf()
            {
                var merger = new PdfFileMerger();

                var b1 = System.IO.File.ReadAllBytes(@"C:\Users\rnaghiyev\Desktop\Files\1.pdf");
                var b2 = System.IO.File.ReadAllBytes(@"C:\Users\rnaghiyev\Desktop\Files\2.pdf");

                byte[] pdfContent = merger.Merge(new System.Collections.Generic.List<byte[]> { b1, b2 });


                if (pdfContent == null)
                {
                    return null;
                }

                var contentDispositionHeader = new System.Net.Mime.ContentDisposition
                {
                    Inline = true,
                    FileName = "someFilename.pdf"
                };

                Response.Headers.Add("Content-Disposition", contentDispositionHeader.ToString());
                return File(pdfContent, System.Net.Mime.MediaTypeNames.Application.Pdf);
            }


            return GetTiff();

        }

        public IActionResult GetTiff()
        {
            var merger = new TiffFileMerger();

            var b1 = System.IO.File.ReadAllBytes(@"C:\Users\rnaghiyev\Desktop\Files\1.tiff");
            var b2 = System.IO.File.ReadAllBytes(@"C:\Users\rnaghiyev\Desktop\Files\2.tiff");
            //var b3 = System.IO.File.ReadAllBytes(@"C:\Users\rnaghiyev\Desktop\Files\3.tiff");
            byte[] content = merger.Merge(new System.Collections.Generic.List<byte[]> { b1, b2 });


            if (content == null)
            {
                return null;
            }

            var contentDispositionHeader = new System.Net.Mime.ContentDisposition
            {
                Inline = true,
                FileName = "someFilename.pdf"
            };

            var pdfContent = FileConvertor.Tiff2Pdf(content);
            Response.Headers.Add("Content-Disposition", contentDispositionHeader.ToString());
            return File(pdfContent, System.Net.Mime.MediaTypeNames.Application.Pdf);
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
